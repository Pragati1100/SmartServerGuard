import os
import psutil

def get_metrics():
    memory = psutil.virtual_memory().percent
    temp_data = psutil.sensors_temperatures()
    temperature = temp_data.get('coretemp', [{'current': 50.0}])[0]['current'] if 'coretemp' in temp_data else 50.0
    cpu = psutil.cpu_percent()
    load_avg = os.getloadavg()[0]
    return [memory, temperature, cpu, load_avg]
