import socket
import platform
import subprocess
import psutil  # pip install psutil

def get_all_local_subnet_prefixes():
    subnet_prefixes = set()
    
    for interface, addrs in psutil.net_if_addrs().items():
        for addr in addrs:
            if addr.family == socket.AF_INET:
                ip = addr.address
                if ip.startswith("127.") or ip.startswith("169.254."):
                    continue  # skip localhost and APIPA
                subnet_prefix = '.'.join(ip.split('.')[:3])
                subnet_prefixes.add(subnet_prefix)

    return list(subnet_prefixes)

def get_subnet_ips(subnet_prefix):
    return [f"{subnet_prefix}.{i}" for i in range(1, 255)]

def is_ping_successful(ip):
    """Ping an IP address to see if it's alive."""
    param = "-n" if platform.system().lower() == "windows" else "-c"
    timeout_param = "-w" if platform.system().lower() == "windows" else "-W"
    try:
        result = subprocess.run(
            ["ping", param, "1", timeout_param, "1", ip],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        return result.returncode == 0
    except Exception:
        return False

def get_active_ips(ip_list):
    active_ips = []
    for ip in ip_list:
        if is_ping_successful(ip):
            active_ips.append(ip)
    return active_ips

def discover_active_ips_auto():
    subnet_prefixes = get_all_local_subnet_prefixes()
    all_active_ips = []

    for subnet in subnet_prefixes:
        print(f"[🔍] Scanning subnet {subnet}.0/24...")
        ip_range = get_subnet_ips(subnet)
        active_ips = get_active_ips(ip_range)
        all_active_ips.extend(active_ips)

    print("[📡] Active IPs across all interfaces:", all_active_ips)
    return all_active_ips
