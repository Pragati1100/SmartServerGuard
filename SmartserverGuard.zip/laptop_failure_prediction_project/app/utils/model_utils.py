import pickle
import threading
import datetime
import pandas as pd  # Needed to write to CSV
import os
from app.utils.system_metrics import get_metrics

# Thread-safe live data dictionary
live_data = {}
data_lock = threading.Lock()

# Load model and scaler
with open(r"D:\Semester_Final_Project_Mtech\laptop_failure_prediction_project\model\model.pkl", "rb") as f:
    model = pickle.load(f)
with open(r"D:\Semester_Final_Project_Mtech\laptop_failure_prediction_project\model\scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

def prediction_loop(ip, socketio):
    while True:
        try:
            metrics = get_metrics()
            scaled = scaler.transform([metrics])
            prediction = model.predict(scaled)[0]
            label = "Failure" if prediction == 1 else "No Failure"
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            with data_lock:
                if ip not in live_data:
                    live_data[ip] = []

                # Add the new prediction data
                new_entry = {
                    "timestamp": timestamp,
                    "memory": metrics[0],
                    "temperature": metrics[1],
                    "cpu": metrics[2],
                    "cpu_load_avg": metrics[3],
                    "failure_prediction": label
                }

                live_data[ip].append(new_entry)

                # 💾 Save to CSV in project root (or customize path as needed)
                filename = f"{ip.replace('.', '_')}_monitoring.csv"
                csv_path = os.path.join(os.getcwd(), filename)
                pd.DataFrame(live_data[ip]).to_csv(csv_path, index=False)

            # Emit data to frontend via Socket.IO
            socketio.emit("new_data", new_entry, room=ip)

            socketio.sleep(60)

        except Exception as e:
            print(f"[❌] Prediction error: {e}")
            socketio.sleep(60)
