import socket

def run_client():
    host = '0.0.0.0'
    port = 5001

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(1)
    print(f"[📡] Client listening on {host}:{port}")

    while True:
        conn, addr = s.accept()
        print(f"[🔗] Dashboard pinged from {addr}")
        conn.close()

if __name__ == '__main__':
    run_client()
