from flask import Blueprint, render_template
from app.utils.network_utils import discover_active_ips_auto

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/')
def index():
    devices = discover_active_ips_auto()  # Automatically discovers from all subnets
    return render_template('dashboard.html', devices=devices)
