# app/routes/main.py

from flask import Blueprint, render_template
from ..utils.network_utils import scan_network

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def dashboard():
    devices = scan_network()
    print("[✅] Devices found:", devices)
    return render_template('dashboard.html', devices=devices)
