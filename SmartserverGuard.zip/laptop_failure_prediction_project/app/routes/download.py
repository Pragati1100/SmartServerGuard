from flask import Blueprint, send_file, abort
import os

download_bp = Blueprint('download', __name__)

@download_bp.route('/download/<ip>')
def download_csv(ip):
    path = f'monitoring_data/{ip}.csv'
    if os.path.exists(path):
        return send_file(path, as_attachment=True)
    else:
        return abort(404, description="Monitoring file not found.")
