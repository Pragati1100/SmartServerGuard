import time
from datetime import datetime
import csv
import os
import psutil
from app import socketio
from real_time_prediction import predict_failure

def collect_metrics_and_emit(ip):
    filename = f'monitoring_data/{ip}.csv'
    os.makedirs('monitoring_data', exist_ok=True)

    with open(filename, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["Timestamp", "Memory", "Temperature", "CPU", "CPU_Load_Avg", "Failure_Prediction"])

    while True:
        memory = psutil.virtual_memory().percent
        temperature = 75.0  # fixed idle temperature (since Windows lacks sensors)
        cpu = psutil.cpu_percent(interval=1)
        cpu_load_avg = round(cpu / 100 * psutil.cpu_count(), 2)  # approximate load average

        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        prediction = predict_failure([memory, temperature, cpu, cpu_load_avg])

        row = [timestamp, memory, temperature, cpu, cpu_load_avg, prediction]
        with open(filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(row)

        socketio.emit('new_data', {
            "timestamp": timestamp,
            "memory": memory,
            "temperature": temperature,
            "cpu": cpu,
            "cpu_load_avg": cpu_load_avg,
            "failure_prediction": prediction
        })

        time.sleep(2)
