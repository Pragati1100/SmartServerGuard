import random
import threading
import time
from flask import Blueprint, render_template
from app import socketio
from app.routes.monitor_helpers import collect_metrics_and_emit

monitor_bp = Blueprint('monitor', __name__)

@monitor_bp.route('/monitor/<ip>')
def monitor_page(ip):
    threading.Thread(target=collect_metrics_and_emit, args=(ip,), daemon=True).start()
    return render_template('monitor.html', ip=ip)
