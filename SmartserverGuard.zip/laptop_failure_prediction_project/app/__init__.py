from flask import Flask
from flask_socketio import SocketIO

socketio = SocketIO()

def create_app():
    app = Flask(__name__)

    from app.routes.dashboard import dashboard_bp
    from app.routes.monitor import monitor_bp
    from app.routes.download import download_bp

    app.register_blueprint(dashboard_bp)
    app.register_blueprint(monitor_bp)
    app.register_blueprint(download_bp)

    return app
