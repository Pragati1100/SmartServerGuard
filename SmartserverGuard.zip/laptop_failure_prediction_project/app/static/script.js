// script.js

// Function to fetch real-time data
function fetchRealTimeData() {
    fetch('/real-time-data')
        .then(response => response.json())
        .then(data => {
            document.getElementById("cpu").textContent = `CPU Usage: ${data.cpu}%`;
            document.getElementById("memory").textContent = `Memory Usage: ${data.memory}%`;
            document.getElementById("disk-read").textContent = `Disk Read: ${data.disk_read} MB`;
            document.getElementById("disk-write").textContent = `Disk Write: ${data.disk_write} MB`;
            document.getElementById("network-latency").textContent = `Network Latency: ${data.network_latency} ms`;
            document.getElementById("temperature").textContent = `CPU Temperature: ${data.temperature}°C`;
            document.getElementById("uptime").textContent = `Uptime: ${data.uptime} hours`;
            document.getElementById("fan-speed").textContent = `Fan Speed: ${data.fan_speed} RPM`;
            document.getElementById("battery-health").textContent = `Battery Health: ${data.battery_health}%`;
        });
}

// Function to fetch health status
function fetchHealthStatus() {
    fetch('/predict-failure')
        .then(response => response.json())
        .then(data => {
            const healthStatus = document.getElementById("health-status");
            healthStatus.textContent = data.status;
            healthStatus.style.color = data.status === "Failure Detected" ? "#ff4f4f" : "#66ff66";
        });
}

// Function to download the data as a file
function downloadData() {
    fetch('/real-time-data')
        .then(response => response.json())
        .then(data => {
            let csvData = "Metric,Value\n";
            for (const key in data) {
                if (data.hasOwnProperty(key)) {
                    csvData += `${key},${data[key]}\n`;
                }
            }

            const blob = new Blob([csvData], { type: 'text/csv' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'laptop_data.csv';
            link.click();
        });
}

// Fetch data every 3 seconds and update the page
setInterval(() => {
    fetchRealTimeData();
    fetchHealthStatus();
}, 3000);
// Function to generate real-time data
function generateData() {
    fetch('/generate_data')
        .then(response => response.json())
        .then(data => {
            alert(data.message || "Data generated successfully");
        })
        .catch(error => {
            alert("Error generating data: " + error);
        });
}

// Function to download CSV
function downloadCSV() {
    window.location.href = '/download_csv';
}
