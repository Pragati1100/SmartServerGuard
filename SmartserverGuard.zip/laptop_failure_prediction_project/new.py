import pandas as pd
from sklearn.utils import resample

# Load your original dataset
df = pd.read_csv("Data.csv")  # Ensure this file is in your working directory

# Step 1: Denormalize (assuming 0-1 normalization range)
df['memory'] = df['memory'] * 100            # % usage
df['temperature'] = df['temperature'] * 100  # °C
df['cpu'] = df['cpu'] * 100                  # % usage
df['cpu_load_avg'] = df['cpu_load_avg'] * 10 # load

# Step 2: Apply real-world failure rule
df['failure'] = (
    (df['memory'] > 80) &
    (df['temperature'] > 80) &
    (df['cpu'] > 75) &
    (df['cpu_load_avg'] > 5)
).astype(int)

# Step 3: Balance the dataset
df_majority = df[df['failure'] == 0]
df_minority = df[df['failure'] == 1]

# Oversample minority class
df_minority_upsampled = resample(
    df_minority,
    replace=True,
    n_samples=1000,
    random_state=42
)

# Downsample majority class
df_majority_downsampled = resample(
    df_majority,
    replace=False,
    n_samples=1000,
    random_state=42
)

# Combine balanced dataset
df_balanced = pd.concat([df_majority_downsampled, df_minority_upsampled])
df_balanced = df_balanced.sample(frac=1, random_state=42).reset_index(drop=True)

# Select final features and label
df_balanced_final = df_balanced[['memory', 'temperature', 'cpu', 'cpu_load_avg', 'failure']]

# Save to CSV
df_balanced_final.to_csv("dataset.csv", index=False)

print("✅ Balanced dataset saved as 'dataset.csv'")
