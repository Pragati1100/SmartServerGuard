import numpy as np
import pickle

model = pickle.load(open('D:\\Semester_Final_Project_Mtech\\laptop_failure_prediction_project\\model\\model\\model.pkl', 'rb'))
scaler = pickle.load(open('D:\\Semester_Final_Project_Mtech\\laptop_failure_prediction_project\\model\\model\\scaler.pkl', 'rb'))


def predict_failure(input_metrics):
    try:
        data = np.array(input_metrics).reshape(1, -1)
        scaled = scaler.transform(data)
        prediction = model.predict(scaled)[0]
        return "Failure" if prediction == 1 else "No Failure"
    except Exception as e:
        print(f"[ERROR] Prediction failed: {e}")
        return "Error"
